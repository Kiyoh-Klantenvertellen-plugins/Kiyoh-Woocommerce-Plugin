<?php

class Kiyoh_Product_Sync_Manager {

    /**
     * Maximum length allowed for product_code. Kiyoh requires codes to be under
     * 50 characters, so we cap at 49.
     */
    const MAX_PRODUCT_CODE_LENGTH = 49;

    /**
     * Number of hash characters appended when a code has to be truncated, to
     * keep truncated codes unique.
     */
    const PRODUCT_CODE_HASH_LENGTH = 8;

    private $api_client;
    private $settings;

    public function __construct() {
        $this->settings = get_option('kiyoh_woocommerce_settings', array());
        $this->init_hooks();
    }

    private function init_hooks() {
        if (!$this->is_sync_enabled()) {
            return;
        }

        add_action('woocommerce_new_product', array($this, 'handle_product_creation'), 10, 1);
        add_action('woocommerce_update_product', array($this, 'handle_product_update'), 10, 1);
        add_action('wp_ajax_kiyoh_bulk_sync_products', array($this, 'ajax_bulk_sync_products'));
    }

    private function is_sync_enabled() {
        return !empty($this->settings['general']['enabled']) && 
               !empty($this->settings['product_sync']['auto_sync']) &&
               !empty($this->settings['general']['api_key']) &&
               !empty($this->settings['general']['location_id']);
    }

    public function handle_product_creation($product_id) {
        error_log("Kiyoh Product Sync: Product creation hook triggered for product {$product_id}");
        $this->sync_single_product($product_id);
    }

    public function handle_product_update($product_id) {
        error_log("Kiyoh Product Sync: Product update hook triggered for product {$product_id}");
        $this->sync_single_product($product_id);
    }

    public function sync_single_product($product_id) {
        try {
            if (!$this->should_sync_product($product_id)) {
                error_log("Kiyoh Product Sync: Product {$product_id} excluded from sync");
                return false;
            }

            $product_data = $this->extract_product_data($product_id);
            if (!$product_data) {
                error_log("Kiyoh Product Sync: Failed to extract data for product {$product_id}");
                return false;
            }

            $api_client = $this->get_api_client();
            if (!$api_client) {
                error_log("Kiyoh Product Sync: API client not available for product {$product_id}");
                return false;
            }

            $response = $api_client->sync_product($product_data);
            
            $this->update_sync_status($product_id, $response);
            
            if ($response->is_success()) {
                error_log("Kiyoh Product Sync: Successfully synced product {$product_id} (SKU: {$product_data['product_code']})");
            } else {
                error_log("Kiyoh Product Sync: Failed to sync product {$product_id}: " . $response->get_error());
            }
            
            return $response->is_success();
        } catch (Exception $e) {
            error_log("Kiyoh Product Sync: Exception syncing product {$product_id}: " . $e->getMessage());
            return false;
        }
    }

    public function bulk_sync_products($filters = array()) {
        $products = $this->get_products_for_sync($filters);
        $results = array(
            'total' => count($products),
            'synced' => 0,
            'errors' => 0,
            'skipped' => 0,
            'error_messages' => array()
        );

        if (empty($products)) {
            return $results;
        }

        $api_client = $this->get_api_client();
        if (!$api_client) {
            $results['errors'] = count($products);
            $results['error_messages'][] = __('API client could not be initialised. Check that the API key, Location ID and platform are configured correctly under the General tab.', 'kiyoh-woocommerce');
            return $results;
        }

        // Process in batches of 50 for better performance
        $batch_size = 50;
        $batches = array_chunk($products, $batch_size);

        foreach ($batches as $batch) {
            $batch_data = array();
            $batch_product_ids = array();

            foreach ($batch as $product_id) {
                if (!$this->should_sync_product($product_id)) {
                    $results['skipped']++;
                    continue;
                }

                $product_data = $this->extract_product_data($product_id);
                if ($product_data) {
                    // Remove location_id from individual product data for bulk sync
                    unset($product_data['location_id']);
                    $batch_data[] = $product_data;
                    $batch_product_ids[] = $product_id;
                }
            }

            if (!empty($batch_data)) {
                try {
                    $response = $api_client->sync_products_bulk($batch_data);
                    
                    if ($response->is_success()) {
                        $results['synced'] += count($batch_data);
                        
                        // Update sync status for all products in batch
                        foreach ($batch_product_ids as $product_id) {
                            $this->update_sync_status($product_id, $response);
                        }
                    } else {
                        $results['errors'] += count($batch_data);

                        // Dump the FULL error response verbatim. Kiyoh returns a
                        // generic HTTP 500 / "An exception has occurred" for many
                        // real failures, and the actual cause only lives in the
                        // detailedError array (e.g. INVALID_HASH) or the raw body.
                        // We stop trying to make this pretty and surface everything
                        // so the merchant/dev can see exactly what happened.
                        $http_code       = $response->get_response_code();
                        $detailed_errors = $response->get_detailed_errors();
                        $raw_body        = $response->get_raw_body();

                        $detail = sprintf(
                            /* translators: 1: number of products in the failed batch, 2: HTTP status code */
                            __('Batch of %1$d product(s) failed (HTTP %2$s)', 'kiyoh-woocommerce'),
                            count($batch_data),
                            $http_code ? $http_code : '?'
                        );

                        if (!empty($detailed_errors) && is_array($detailed_errors)) {
                            $detail .= ' | detailedError: ' . wp_json_encode($detailed_errors);
                        }

                        // Always include the raw response body so nothing is hidden.
                        if (!empty($raw_body)) {
                            $detail .= ' | raw: ' . $raw_body;
                        } elseif ($response->get_error()) {
                            $detail .= ' | ' . $response->get_error();
                        }

                        $results['error_messages'][] = $detail;

                        // Log full error for batch
                        error_log('Kiyoh Bulk Sync Error: ' . $detail);

                        // When Kiyoh returns a generic 500 with no field detail,
                        // the only way to find the offending product is to bisect
                        // the batch. This is expensive (extra API calls + rate
                        // limit), so it is opt-in via the KIYOH_DIAGNOSE_BATCH
                        // constant (define it in wp-config.php while debugging).
                        if (defined('KIYOH_DIAGNOSE_BATCH') && KIYOH_DIAGNOSE_BATCH) {
                            $this->diagnose_failing_batch($api_client, $batch_data);
                        }

                        // Update sync status with error for all products in batch
                        foreach ($batch_product_ids as $product_id) {
                            $this->update_sync_status($product_id, $response);
                        }
                    }
                } catch (Exception $e) {
                    $results['errors'] += count($batch_data);
                    $results['error_messages'][] = sprintf(
                        /* translators: %s: PHP exception message */
                        __('Batch failed with exception: %s', 'kiyoh-woocommerce'),
                        $e->getMessage()
                    );
                    error_log('Kiyoh Bulk Sync Exception: ' . $e->getMessage());
                }
            }

            // Add delay between batches to prevent rate limiting
            sleep(3);
        }

        return $results;
    }

    /**
     * Bisect a failing batch to isolate the exact product(s) that make Kiyoh
     * return a generic HTTP 500. Logs the full JSON payload of each offending
     * product so the real cause (bad image_url, weird character, etc.) can be
     * identified. Opt-in via KIYOH_DIAGNOSE_BATCH because it fires extra API
     * requests (throttled by a short sleep to respect rate limits).
     *
     * @param Kiyoh_Api_Client $api_client
     * @param array            $products  Product payloads (no location_id).
     * @param int              $depth     Recursion depth (internal).
     * @return void
     */
    private function diagnose_failing_batch($api_client, $products, $depth = 0) {
        $count = count($products);

        if ($count === 0) {
            return;
        }

        // Base case: a single product. Re-send it alone and log the verdict.
        if ($count === 1) {
            sleep(1);
            $response = $api_client->sync_products_bulk($products);
            $payload  = wp_json_encode($products[0]);
            if ($response->is_success()) {
                error_log('Kiyoh Diagnose: product SYNCS OK alone: ' . $payload);
            } else {
                error_log(sprintf(
                    'Kiyoh Diagnose: OFFENDING PRODUCT (HTTP %s, %s): %s',
                    $response->get_response_code() ?: '?',
                    $response->get_error_code() ?: 'error',
                    $payload
                ));
            }
            return;
        }

        // Split in half and test each side; recurse only into halves that fail.
        $half   = (int) floor($count / 2);
        $first  = array_slice($products, 0, $half);
        $second = array_slice($products, $half);

        foreach (array($first, $second) as $subset) {
            sleep(1);
            $response = $api_client->sync_products_bulk($subset);
            if (!$response->is_success()) {
                error_log(sprintf(
                    'Kiyoh Diagnose: sub-batch of %d still fails (HTTP %s) - bisecting further',
                    count($subset),
                    $response->get_response_code() ?: '?'
                ));
                $this->diagnose_failing_batch($api_client, $subset, $depth + 1);
            }
        }
    }

    private function should_sync_product($product_id) {
        $product = wc_get_product($product_id);
        if (!$product) {
            error_log("Kiyoh Product Sync: Product {$product_id} not found");
            return false;
        }

        // Must have SKU and name to sync
        $sku = $product->get_sku();
        $name = $product->get_name();
        if (!$sku || !$name || trim($sku) === '' || trim($name) === '') {
            error_log("Kiyoh Product Sync: Product {$product_id} missing SKU ('{$sku}') or name ('{$name}') - skipping");
            return false;
        }

        // Check if product type is excluded
        $excluded_types = $this->get_excluded_product_types();
        if (in_array($product->get_type(), $excluded_types)) {
            error_log("Kiyoh Product Sync: Product {$product_id} type '{$product->get_type()}' is excluded - skipping");
            return false;
        }

        // Check if product code is excluded
        $excluded_codes = $this->get_excluded_product_codes();
        if (in_array($sku, $excluded_codes)) {
            error_log("Kiyoh Product Sync: Product {$product_id} SKU '{$sku}' is excluded - skipping");
            return false;
        }

        error_log("Kiyoh Product Sync: Product {$product_id} (SKU: '{$sku}', Name: '{$name}') passed validation - proceeding with sync");
        return true;
    }

    private function extract_product_data($product_id) {
        $product = wc_get_product($product_id);
        if (!$product) {
            return false;
        }

        // Get SKU directly - don't use fallback product ID like Magento
        $raw_product_code = $product->get_sku();
        $product_name = $product->get_name();

        // Both SKU and name are required - no fallbacks
        if (!$raw_product_code || !$product_name || trim($raw_product_code) === '' || trim($product_name) === '') {
            error_log("Kiyoh Product Sync: Product {$product_id} missing required SKU ('{$raw_product_code}') or name ('{$product_name}') - skipping sync");
            return false;
        }

        // Kiyoh validates product_code against a strict server-side pattern and
        // rejects the ENTIRE bulk batch with INVALID_PATTERN (HTTP 400) if a
        // single code contains illegal characters (quotes, spaces, en-dashes,
        // semicolons, other non-ASCII, etc.). Sanitise into a safe code so the
        // batch is not poisoned by one bad SKU.
        $product_code = $this->sanitize_product_code($raw_product_code);
        if ($product_code === '') {
            error_log("Kiyoh Product Sync: Product {$product_id} SKU '{$raw_product_code}' produced an empty code after sanitisation - skipping sync");
            return false;
        }

        if ($product_code !== $raw_product_code) {
            error_log("Kiyoh Product Sync: Product {$product_id} SKU sanitised from '{$raw_product_code}' to '{$product_code}' for Kiyoh compatibility");
        }

        error_log("Kiyoh Product Sync: Extracting data for product {$product_id} - SKU: '{$product_code}', Name: '{$product_name}'");

        // Ensure we have a valid product URL
        $product_url = get_permalink($product_id);
        if (!$product_url || !filter_var($product_url, FILTER_VALIDATE_URL)) {
            $product_url = home_url('/product/' . urlencode(strtolower($product_code)));
        }

        // Resolve a valid image URL. Kiyoh requires image_url and will throw a
        // generic INTERNAL_SERVER_ERROR (HTTP 500, no field detail) for the whole
        // atomic batch if the URL is unreachable/invalid. Variations frequently
        // have no image of their own, so fall back to the PARENT product's image
        // before resorting to a placeholder.
        $image_url = $this->resolve_product_image_url($product);
        if (!$image_url || !filter_var($image_url, FILTER_VALIDATE_URL)) {
            // Last resort: a stable, always-available Kiyoh-hosted logo. (The
            // previous via.placeholder.com service was discontinued and its
            // broken images caused Kiyoh to reject entire batches with HTTP 500.)
            $image_url = 'https://astro.kiyoh.com/static/logos/logo-1-dark.svg';
        }

        // Get brand from product attributes or meta
        $brand = $this->get_product_brand($product);

        // Get GTIN and MPN from product meta or attributes
        $gtin = $this->get_product_gtin($product);
        $mpn = $this->get_product_mpn($product);

        // Build the basic required data
        $data = array(
            'location_id' => (string) $this->settings['general']['location_id'],
            'product_code' => (string) $product_code,
            'product_name' => (string) $product_name,
            'source_url' => $product_url,
            'image_url' => $image_url,
            'active' => ($product->get_status() === 'publish')
        );

        // Only add optional fields if they exist and are not empty
        if (!empty($brand)) {
            $data['brand_name'] = (string) $brand;
        }
        
        $sku = $product->get_sku();
        if (!empty($sku)) {
            $data['skus'] = (string) $sku;
        }
        
        // Kiyoh validates gtins as a numeric barcode (8/12/13/14 digits). An
        // invalid length or non-numeric value triggers INVALID_PATTERN and, in a
        // bulk request, fails the whole batch. Only send valid GTINs; otherwise
        // omit the field so the product still syncs.
        if (!empty($gtin) && $this->is_valid_gtin($gtin)) {
            $data['gtins'] = (string) $gtin;
        } elseif (!empty($gtin)) {
            error_log("Kiyoh Product Sync: Product {$product_id} GTIN '{$gtin}' is invalid - omitting from sync");
        }
        
        if (!empty($mpn)) {
            $data['mpns'] = (string) $mpn;
        }

        return $data;
    }

    private function get_product_code($product) {
        // Use SKU as product code, fallback to product ID
        $sku = $product->get_sku();
        return !empty($sku) ? $sku : 'product_' . $product->get_id();
    }

    /**
     * Resolve a usable full-size image URL for a product.
     *
     * Variations often have no image of their own; in that case we fall back to
     * the parent variable product's featured image. Returns '' when nothing
     * usable is found so the caller can apply a final placeholder.
     *
     * @param WC_Product $product
     * @return string
     */
    private function resolve_product_image_url($product) {
        // 1. The product's own featured image.
        $image_id = $product->get_image_id();
        if ($image_id) {
            $url = wp_get_attachment_image_url($image_id, 'full');
            if ($url && filter_var($url, FILTER_VALIDATE_URL)) {
                return $url;
            }
        }

        // 2. For a variation, inherit the parent variable product's image.
        if (is_callable(array($product, 'get_parent_id'))) {
            $parent_id = $product->get_parent_id();
            if ($parent_id) {
                $parent = wc_get_product($parent_id);
                if ($parent) {
                    $parent_image_id = $parent->get_image_id();
                    if ($parent_image_id) {
                        $url = wp_get_attachment_image_url($parent_image_id, 'full');
                        if ($url && filter_var($url, FILTER_VALIDATE_URL)) {
                            return $url;
                        }
                    }
                }
            }
        }

        return '';
    }

    /**
     * Sanitise a raw SKU into a Kiyoh-safe product_code.
     *
     * Kiyoh rejects product_code values that contain characters outside a
     * conservative safe set (letters, digits, dot, underscore, hyphen, slash)
     * with INVALID_PATTERN (HTTP 400). Because the bulk endpoint validates the
     * whole payload atomically, a single bad code fails the entire batch of 50.
     *
     * We transliterate accented/Unicode characters to ASCII where possible,
     * strip quotes, collapse whitespace and any other illegal character into a
     * single hyphen, then trim stray separators. The result is deterministic so
     * repeated syncs map the same SKU to the same code.
     *
     * Kiyoh also limits product_code length to under 50 characters. Codes longer
     * than self::MAX_PRODUCT_CODE_LENGTH (49) are truncated and a short hash of
     * the ORIGINAL raw SKU is appended, guaranteeing the result stays under the
     * limit while remaining unique (two long SKUs sharing the same 40-char prefix
     * still map to different codes) and deterministic (same SKU -> same code).
     *
     * @param string $sku Raw SKU from WooCommerce.
     * @return string Sanitised code, or '' if nothing usable remains.
     */
    public static function sanitize_product_code($sku) {
        $code = (string) $sku;

        // Normalise common Unicode dashes to ASCII hyphen before stripping.
        $code = str_replace(
            array("\xE2\x80\x93", "\xE2\x80\x94", "\xE2\x80\x92", "\xE2\x88\x92"),
            '-',
            $code
        );

        // Transliterate remaining non-ASCII (accents etc.) to ASCII when possible.
        if (function_exists('iconv')) {
            $transliterated = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $code);
            if ($transliterated !== false) {
                $code = $transliterated;
            }
        }

        // Remove quotes entirely (they break both the pattern and JSON safety).
        $code = str_replace(array('"', "'", '`'), '', $code);

        // Replace any character outside the safe set with a hyphen.
        $code = preg_replace('/[^A-Za-z0-9._\-\/]+/', '-', $code);

        // Collapse repeated hyphens and trim leading/trailing separators.
        $code = preg_replace('/-{2,}/', '-', $code);
        $code = trim($code, "-._/ \t\n\r\0\x0B");

        // Enforce the maximum length. If we truncate, append a short hash of the
        // original SKU so uniqueness is preserved across long codes that share a
        // prefix. Layout: <prefix>-<8-char hash>  (40 + 1 + 8 = 49, under 50).
        if (strlen($code) > self::MAX_PRODUCT_CODE_LENGTH) {
            $hash    = substr(md5((string) $sku), 0, self::PRODUCT_CODE_HASH_LENGTH);
            $prefix_len = self::MAX_PRODUCT_CODE_LENGTH - self::PRODUCT_CODE_HASH_LENGTH - 1; // -1 for the '-'
            $prefix  = substr($code, 0, $prefix_len);
            // Avoid a trailing separator right before the hash join.
            $prefix  = rtrim($prefix, "-._/");
            $code    = $prefix . '-' . $hash;
        }

        return $code;
    }

    /**
     * Validate a GTIN against Kiyoh's expected numeric barcode format.
     *
     * @param string $gtin Candidate GTIN.
     * @return bool True when it is 8, 12, 13 or 14 numeric digits.
     */
    private function is_valid_gtin($gtin) {
        $gtin = trim((string) $gtin);
        if (!ctype_digit($gtin)) {
            return false;
        }
        return in_array(strlen($gtin), array(8, 12, 13, 14), true);
    }

    private function get_product_brand($product) {
        // Check for brand product attribute (Attributes tab)
        $brand_attribute = $product->get_attribute('brand');
        if (!empty($brand_attribute)) {
            return $brand_attribute;
        }

        // Check for brand taxonomy (WooCommerce Brands / Perfect Brands plugins)
        $brand_taxonomies = array('product_brand', 'pwb-brand', 'yith_product_brand');
        foreach ($brand_taxonomies as $taxonomy) {
            $brand_terms = get_the_terms($product->get_id(), $taxonomy);
            if (!empty($brand_terms) && !is_wp_error($brand_terms)) {
                return $brand_terms[0]->name;
            }
        }

        // Check for brand in meta fields
        $brand_fields = array('_brand', 'brand', '_manufacturer', 'manufacturer');
        foreach ($brand_fields as $field) {
            $brand_meta = get_post_meta($product->get_id(), $field, true);
            if (!empty($brand_meta)) {
                return $brand_meta;
            }
        }

        return '';
    }

    private function get_product_gtin($product) {
        // Check WooCommerce built-in GTIN field first (Product → Inventory → "GTIN, UPC, EAN, or ISBN")
        $global_unique_id = $product->get_global_unique_id();
        if (!empty($global_unique_id)) {
            return $global_unique_id;
        }

        // Check for GTIN in various meta fields
        $gtin_fields = array('_global_unique_id', '_gtin', '_gtin14', '_gtin13', '_gtin12', '_gtin8', '_ean', '_upc');
        
        foreach ($gtin_fields as $field) {
            $gtin = get_post_meta($product->get_id(), $field, true);
            if (!empty($gtin)) {
                return $gtin;
            }
        }

        // Check for GTIN attribute
        $gtin_attribute = $product->get_attribute('gtin');
        if (!empty($gtin_attribute)) {
            return $gtin_attribute;
        }

        return '';
    }

    private function get_product_mpn($product) {
        // Check for MPN in meta fields
        $mpn_fields = array('_mpn', '_manufacturer_part_number', '_part_number');
        
        foreach ($mpn_fields as $field) {
            $mpn = get_post_meta($product->get_id(), $field, true);
            if (!empty($mpn)) {
                return $mpn;
            }
        }

        // Check for MPN attribute
        $mpn_attribute = $product->get_attribute('mpn');
        if (!empty($mpn_attribute)) {
            return $mpn_attribute;
        }

        return '';
    }

    private function get_excluded_product_types() {
        $excluded = isset($this->settings['product_sync']['excluded_types']) ? 
                   $this->settings['product_sync']['excluded_types'] : array();
        return is_array($excluded) ? $excluded : array();
    }

    private function get_excluded_product_codes() {
        $excluded_codes_text = isset($this->settings['product_sync']['excluded_codes']) ? 
                              $this->settings['product_sync']['excluded_codes'] : '';
        
        if (empty($excluded_codes_text)) {
            return array();
        }

        // Split by both lines and commas, then clean up
        $codes = preg_split('/[\n,]+/', $excluded_codes_text);
        $codes = array_map('trim', $codes);
        $codes = array_filter($codes); // Remove empty entries
        
        return $codes;
    }

    private function get_products_for_sync($filters = array()) {
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'fields' => 'ids'
        );

        // Apply filters if provided
        if (!empty($filters['product_types'])) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_type',
                    'field' => 'slug',
                    'terms' => $filters['product_types']
                )
            );
        }

        $query = new WP_Query($args);
        return $query->posts;
    }

    private function get_api_client() {
        if (!$this->api_client) {
            $platform = isset($this->settings['general']['platform']) ? $this->settings['general']['platform'] : 'kiyoh';
            $api_key = isset($this->settings['general']['api_key']) ? $this->settings['general']['api_key'] : '';
            $location_id = isset($this->settings['general']['location_id']) ? $this->settings['general']['location_id'] : '';

            if (empty($api_key) || empty($location_id)) {
                return false;
            }

            $this->api_client = new Kiyoh_Api_Client($platform, $api_key, $location_id);
        }

        return $this->api_client;
    }

    private function update_sync_status($product_id, $response) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'kiyoh_product_sync';
        
        $data = array(
            'product_id' => $product_id,
            'last_sync' => current_time('mysql'),
            'sync_status' => $response->is_success() ? 'success' : 'error',
            'error_message' => $response->is_success() ? null : $response->get_error(),
            'updated_at' => current_time('mysql')
        );

        // Check if record exists
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table_name} WHERE product_id = %d",
            $product_id
        ));

        if ($existing) {
            $wpdb->update($table_name, $data, array('product_id' => $product_id));
        } else {
            $data['created_at'] = current_time('mysql');
            $wpdb->insert($table_name, $data);
        }
    }

    public function ajax_bulk_sync_products() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'kiyoh_admin_nonce')) {
            wp_die('Security check failed');
        }

        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Insufficient permissions');
        }

        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $per_page = 50; // Process 50 products per batch
        
        $offset = ($page - 1) * $per_page;
        
        // Get products for this batch
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            'offset' => $offset,
            'fields' => 'ids'
        );

        $query = new WP_Query($args);
        $products = $query->posts;
        $total_products = $query->found_posts;

        $results = array(
            'batch_synced' => 0,
            'batch_errors' => 0,
            'batch_skipped' => 0,
            'total_products' => $total_products,
            'current_page' => $page,
            'has_more' => count($products) === $per_page
        );

        foreach ($products as $product_id) {
            if (!$this->should_sync_product($product_id)) {
                $results['batch_skipped']++;
                continue;
            }

            $success = $this->sync_single_product($product_id);
            if ($success) {
                $results['batch_synced']++;
            } else {
                $results['batch_errors']++;
            }

            // Small delay between products
            usleep(500000); // 0.5 seconds
        }

        wp_send_json_success($results);
    }

    public function get_sync_statistics() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'kiyoh_product_sync';
        
        $stats = $wpdb->get_row("
            SELECT 
                COUNT(*) as total_synced,
                SUM(CASE WHEN sync_status = 'success' THEN 1 ELSE 0 END) as successful,
                SUM(CASE WHEN sync_status = 'error' THEN 1 ELSE 0 END) as errors,
                MAX(last_sync) as last_sync_time
            FROM {$table_name}
        ");

        // Get total products count
        $total_products = wp_count_posts('product')->publish;

        return array(
            'total_products' => $total_products,
            'total_synced' => $stats->total_synced ?: 0,
            'successful' => $stats->successful ?: 0,
            'errors' => $stats->errors ?: 0,
            'last_sync_time' => $stats->last_sync_time,
            'sync_percentage' => $total_products > 0 ? round(($stats->total_synced / $total_products) * 100, 1) : 0
        );
    }
}